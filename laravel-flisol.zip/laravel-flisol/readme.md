## Creación de sitios web con Laravel

Laravel es un Framework PHP para la creación de sitios web, actualmente es uno de los mas populares debido a su simpleza, flexibilidad, robustez y baja curva de aprendizaje siendo ideal tanto para nuevos usuario como avanzados.

El taller abarcara los temas esenciales para el conocimiento y uso de Laravel 5 mediante la creación de un sitio sencillo.

## Documentación

* [Sitio web](http://laravel.com/docs)
* [Instalación](http://laravel.com/docs)
