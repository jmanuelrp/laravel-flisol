<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'WelcomeController@index');

Route::get('home', 'HomeController@index');

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);

Route::resource('productos', 'Productos');

Route::get('categorias', function() {
	// select * from categorias
	return App\Categoria::all();
});

Route::get('categorias/{id}/productos', function($id) {
	// select * from categorias where id=$id
	$categoria = App\Categoria::findOrFail($id);

	// select * from productos where categoria_id=$categoria->id
	return $categoria->productos;
});
