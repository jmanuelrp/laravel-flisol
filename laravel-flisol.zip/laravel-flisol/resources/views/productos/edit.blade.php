@extends('app')

@section('content')

{!! Form::open(['route' => ['productos.update', $producto->id], 'method' => 'PUT', 'class' => 'form-horizontal']) !!}

		<div class="form-group">
			{!! Form::label('nombre', 'Nombre', ['class'=>'col-sm-2 control-label']) !!}
			<div class="col-sm-10">
				{!! Form::text('nombre', $producto->nombre, ['class'=>'form-control']) !!}
			</div>
		</div>
		<div class="form-group">
			{!! Form::label('stock', 'Stock', ['class'=>'col-sm-2 control-label']) !!}
			<div class="col-sm-10">
				{!! Form::text('stock', $producto->stock, ['class'=>'form-control']) !!}
			</div>
		</div>
		<div class="form-group">
			{!! Form::label('precio', 'Precio', ['class'=>'col-sm-2 control-label']) !!}
			<div class="col-sm-10">
				{!! Form::text('precio', $producto->precio, ['class'=>'form-control']) !!}
			</div>
		</div>

		<div class="form-group">
			<label for="imagen" class="col-sm-2 control label">
				Imagen
			</label>
			<div class="col-sm-10">
				<input type="text" id="imagen" value="{{$producto->imagen}}" class="form-control">
			</div>
		</div>

		<div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
				<button type="submit" class="btn btn-success">Registrar</button>
			</div>
		</div>

		<div class="form-group">
	    <div class="col-sm-offset-2 col-sm-10">
	      
	    </div>
	  </div>
	

	{!! Form::close() !!}

@endsection