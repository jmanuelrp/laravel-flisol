@extends('app')

@section('content')

<div class="row">
	@foreach($productos as $producto)
<div class="col-sm-4">
<div class="thumbnail">
  <img src="{{$producto->imagen}}" alt="...">
  <div class="caption">
    <h3>{{$producto->nombre}}</h3>
    <p>Categoria: {{$producto->categoria->nombre}}</p>
    <p>Precio: {{$producto->precio}}</p>
    <p>
    	<a 
    		href="{{route('productos.edit', ['productos'=>$producto->id])}}"
    		class="btn btn-primary btn-xs"
    		role="button">Editar</a>

    	<a href="#" class="btn btn-danger btn-xs" role="button">Eliminar</a></p>
  </div>
</div>
</div>

	@endforeach
</div>
<div class="row">
	{!!$productos->render()!!}
</div>

@endsection